# Master Question Chain — Index
## "I Bet I Can Get You to God in First Principles"
### David Lowe | POF 2828 | May 2026

---

## How This Works

Each question is one file. Each file has 7 layers:

1. **The Hook** — A self-defeating statement or rhetorical trap. The kind of sentence that destroys itself if you try to deny it.
2. **The Human Story** — Marriage frame (primary), parent/child (accent), courtroom (accent). The reader FEELS the answer before thinking it.
3. **The Metaphysical Lock** — The first-principles structure underneath. Why the answer must be what it is.
4. **The Theological Register** — What Scripture says. Not proof-texting — structural alignment.
5. **The Physics Bridge** — The isomorphism. Same structure, different domain. Process-mapping, not substance-identity.
6. **The Mathematical Skeleton** — Lean 4 targets. What's proven. What's bridge. What's open.
7. **The Objections** — Strongest rival answers. Kill conditions. What would break this beat.

---

## The Chain

### Phase 0 — The Floor
| # | File | Hook | Core Claim |
|---|---|---|---|
| Q00 | Q00_truth_before_error.md | "There is no truth." Is that true? | Truth is prior to error |
| Q01 | Q01_evil_is_parasitic.md | "Good and evil are equal." Then why does evil need good to corrupt? | Evil requires prior good |
| Q02 | Q02_ontological_rightness.md | "Morality is just opinion." Whose opinion says that? | Righteousness is structural |
| Q03 | Q03_error_correction.md | "The universe is random chaos." Then how are you reasoning about it? | Coherence precedes drift |

### Phase 1 — The Claim
| # | File | Hook | Core Claim |
|---|---|---|---|
| Q04 | Q04_resurrection_uniqueness.md | "Resurrection stories are common." Name another one with all five features. | Jesus's claim is structurally unique |

### Phase 2 — What Makes God God
| # | File | Hook | Core Claim |
|---|---|---|---|
| Q05 | Q05_death_defeat.md | "God is immortal." Avoiding death isn't defeating it. | God defeats death, not avoids it |
| Q06 | Q06_board_of_directors.md | "The strongest should rule." Every tyrant agrees with you. | Character over power |
| Q07 | Q07_design_god.md | "God is unknowable." Then why does everyone design Him the same way? | Moral profile converges |

### Phase 3 — Creation and Freedom
| # | File | Hook | Core Claim |
|---|---|---|---|
| Q08 | Q08_why_create.md | "God doesn't need anything." Then why make someone to share it with? | Creation is relational |
| Q09 | Q09_worship_robots.md | "God wants praise." Forced praise is a mirror, not love. | Free will is necessary |
| Q10 | Q10_paradise_test.md | "I'm a good person." Put yourself in paradise with one rule and unlimited time. | Universal failure |

### Phase 4 — The Impossible Problem
| # | File | Hook | Core Claim |
|---|---|---|---|
| Q11 | Q11_who_gets_in.md | "Good people go to heaven." Which good people? By whose standard? | Merit fails |
| Q12 | Q12_pure_mercy.md | "Just forgive everyone." And watch paradise break again. | Mercy alone corrupts |
| Q13 | Q13_pure_justice.md | "Give everyone what they deserve." Including you? | Justice alone empties |
| Q14 | Q14_resume_vs_posture.md | "I've earned it." That sentence is the disqualification. | Posture over performance |

### Phase 5 — Righteousness and Blood
| # | File | Hook | Core Claim |
|---|---|---|---|
| Q15 | Q15_righteousness_sees.md | "A white lie doesn't matter." Tell that to someone who trusted you. | Divine holiness is threshold |
| Q16 | Q16_why_blood.md | "Blood sacrifice is barbaric." So is pretending wrong costs nothing. | Life-cost is real |
| Q17 | Q17_temporary_covering.md | "Why sacrifice again and again?" Because it didn't work yet. | Covering is not completion |

### Phase 6 — Trust and Obedience
| # | File | Hook | Core Claim |
|---|---|---|---|
| Q18 | Q18_parent_calls.md | "I need to understand before I obey." Your child says the same thing at the cliff edge. | Trust precedes full comprehension |
| Q19 | Q19_honest_obedience.md | "I'll obey happily!" That's performance. Gethsemane was honest reluctance plus trust. | Posture is truth, not enthusiasm |

### Phase 7 — Before the Cure
| # | File | Hook | Core Claim |
|---|---|---|---|
| Q20 | Q20_ot_triage.md | "The Old Testament God is cruel." Same surgeon. No antibiotics yet. | Pre-cure containment |
| Q21 | Q21_same_god.md | "God changed between testaments." The medicine changed. The doctor didn't. | Character constant, conditions change |

### Phase 8 — The Solution
| # | File | Hook | Core Claim |
|---|---|---|---|
| Q22 | Q22_why_not_teacher.md | "Just teach people to be good." You already know what's good. Can you do it? | Information doesn't fix nature |
| Q23 | Q23_why_death.md | "Why did Jesus have to die?" Because death is the debt and the system's final weapon. | Cross as mechanism |
| Q24 | Q24_why_rise.md | "Resurrection is impossible." That's the point — the impossible happened. | Resurrection as verification |

### Phase 9 — The Fork
| # | File | Hook | Core Claim |
|---|---|---|---|
| Q25 | Q25_final_trust.md | "I can't believe what I can't prove." You already do. Every day. With everyone you love. | Faith is rational trust |

---

## Self-Defeating Idiom Design Principle

Every hook should be a statement that DESTROYS ITSELF when examined:

- "There is no truth" → Is that true?
- "All morality is relative" → Is that an absolute claim?
- "I'm a good person" → By whose standard? Yours?
- "I've earned it" → That sentence is the disqualification.
- "Just forgive everyone" → Including the person who hurt you most?
- "I need to understand before I obey" → Your two-year-old says the same thing.
- "God should prevent all suffering" → Would you throw your baby off a cliff if it bounced back?

The listener defeats their own objection before you say a word. You just asked the question. They did the work.

---

## Delivery Format

- **Family test:** Read one question per dinner. Discuss. See where they push back.
- **Twitter:** One thread per question. Hook as the first tweet. Layers as thread replies.
- **Substack:** One article per question. Full 7-layer treatment.
- **Stage/TikTok:** Hook + human story only. Link to the full treatment.
- **Academic:** All 25 questions with full math/Lean layer. The paper.

---

## AI Assignments

See: MULTI_AI_QUESTION_BUILDOUT_ASSIGNMENTS.md
