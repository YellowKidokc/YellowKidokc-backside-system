# Audit Database — Deploy & Operate

The living database for Theophysics defensibility snapshots. This is the spine. Postgres holds state; Python workers do extraction; the web layer reads completed snapshots.

---

## Files in this drop

| File | Role |
|---|---|
| `audit_schema_v1.sql` | The schema. 9 layers, 18 tables, 5 views. |
| `audit_schema_v1_1_patch.sql` | Living-database additions: soft-delete, vault scan log, run kinds. |
| `AUDIT_SCHEMA_ARCHITECTURE.md` | Why the schema looks the way it does. |
| `audit_bootstrap.py` | One-time setup: registers the first pipeline version. |
| `vault_watcher.py` | The heartbeat. Hashes vault files, enqueues runs for changes. |
| `audit_worker.py` | The processor. Picks up pending runs, extracts, writes snapshots. Concurrency-safe. |
| `audit_status.py` | Read-only health check. Run this any time to see what's going on. |

---

## Deploy order (do this once)

Set the password env var first so it's not in your shell history:

```cmd
set PG_PASSWORD=Moss9pep28$
```

### 1. Apply the schema

```cmd
"C:\Python313\python.exe" -c "import psycopg2; c=psycopg2.connect(host='192.168.1.97',port=5432,user='postgres',password='%PG_PASSWORD%',dbname='theophysics'); c.autocommit=True; cur=c.cursor(); cur.execute(open(r'C:\path\to\audit_schema_v1.sql').read()); print('v1 done')"

"C:\Python313\python.exe" -c "import psycopg2; c=psycopg2.connect(host='192.168.1.97',port=5432,user='postgres',password='%PG_PASSWORD%',dbname='theophysics'); c.autocommit=True; cur=c.cursor(); cur.execute(open(r'C:\path\to\audit_schema_v1_1_patch.sql').read()); print('patch done')"
```

### 2. Bootstrap (registers the first pipeline so the watcher has a target)

```cmd
"C:\Python313\python.exe" audit_bootstrap.py --vault-name theophysics_v4 --vault-path "O:\_Theophysics_v4"
```

You should see:
```
audit schema OK (20 tables present)
registered pipeline defensibility_v1/0.1.0-stub -> <uuid>
registered vault theophysics_v4 -> <uuid>
bootstrap complete
```

### 3. First scan

```cmd
"C:\Python313\python.exe" vault_watcher.py --vault-name theophysics_v4 --vault-path "O:\_Theophysics_v4"
```

This walks the whole vault, hashes everything, and enqueues a run for every doc against `defensibility_v1`. On a 15K-file vault it should take well under a minute.

### 4. First worker pass (try one run with the stub extractor)

```cmd
"C:\Python313\python.exe" audit_worker.py --once
```

This grabs one pending run, extracts (with the stub), writes a snapshot, marks complete. If this works, the pipeline is alive.

### 5. Check status

```cmd
"C:\Python313\python.exe" audit_status.py
```

You should see your vault listed, a recent scan, pending work counts, and one snapshot.

---

## Operating rhythm

### Every day (automated)

**Watcher** (Windows Task Scheduler, every 15-30 minutes):
```cmd
"C:\Python313\python.exe" vault_watcher.py --vault-name theophysics_v4 --vault-path "O:\_Theophysics_v4" --log "C:\path\to\watcher.log"
```

**Worker** (run continuously, or scheduled if you want bursty processing):
```cmd
"C:\Python313\python.exe" audit_worker.py --loop --poll-seconds 5 --log "C:\path\to\worker.log"
```

**Reaper** (once a day, cleans up stuck runs):
```cmd
"C:\Python313\python.exe" audit_worker.py --reap
```

### When you sit down to work

```cmd
"C:\Python313\python.exe" audit_status.py
```

Tells you: are the vaults being scanned? How much pending work? Critical findings? Repair backlog?

### When you improve the framework

You wrote a better extraction prompt, added a new gap type, or tuned a scorer. Two paths:

**Path A — register a new pipeline version**, then enqueue against current docs:

```sql
-- after audit_bootstrap.py registers the new pipeline
INSERT INTO audit.runs (pipeline_version_id, doc_version_id, run_kind, status)
SELECT '<new_pv_id>', dv.doc_version_id, 'full_extraction', 'pending'
FROM audit.document_versions dv
JOIN audit.documents d ON d.doc_id = dv.doc_id
WHERE dv.superseded_at IS NULL
  AND d.deleted_at IS NULL;
```

That enqueues a re-run for every live doc. Workers chew through them.

**Path B — only added a new scorer**, don't need re-extraction:

Use `run_kind = 'rescore_only'` (worker support for this is the next thing to build; v1 worker only handles `full_extraction`).

---

## How it scales

- Vault grows by 200 notes overnight → 200 pending runs queued by morning. Workers process them at machine speed. You don't notice.
- You delete a vault folder → next watcher pass marks all those docs `deleted_at`. Snapshot history stays. Live views ignore them.
- You edit a single note 5 times in a session → 5 new `document_version` rows, only the latest gets a snapshot (because each new version supersedes the prior pending run via the unique constraint). Cheap.
- A worker dies mid-run → the row stays `running` until the reaper marks it `failed`. Then it can be retried by re-enqueueing.
- Two workers running at once → each grabs different rows via `FOR UPDATE SKIP LOCKED`. No conflicts. This is Postgres doing what it's good at.

---

## When the stub extractor isn't enough

The stub in `audit_worker.py` finds heading-marked sections, `> claim:` lines, and `$$...$$` equation blocks. It exists so the pipeline runs end-to-end before you wire in real model calls.

To plug in a real extractor:

1. Subclass `Extractor` in `audit_worker.py` (or a new file).
2. Implement `extract(raw_markdown, doc_version_id)` returning the same dict shape.
3. Add it to the `EXTRACTORS` dict.
4. Register a new pipeline version in `audit_bootstrap.py` pointing to it.
5. Enqueue runs.

The schema and the worker loop don't change. Just the extraction logic.

---

## Troubleshooting

- **Watcher says `0 runs_enqueued` even though files changed.** No active pipeline registered. Run `audit_bootstrap.py`.
- **Worker says `no pending work` but you know files changed.** Watcher hasn't run yet, or the vault path is wrong. Check `audit_status.py` for `last_scan_at`.
- **Workers fighting each other / duplicate-key errors.** Should not happen with `FOR UPDATE SKIP LOCKED`. If it does, check that you're running workers against the same DB and not test instances.
- **Snapshot table getting huge.** Already partitioned by month from day one. Add new partitions ahead of time (or set up `pg_partman` for auto-creation).
- **Want to re-run a single doc.** Find its current `doc_version_id` and:
  ```sql
  INSERT INTO audit.runs (pipeline_version_id, doc_version_id, run_kind, status)
  SELECT pipeline_version_id, '<dv_id>', 'full_extraction', 'pending'
  FROM audit.pipeline_versions
  WHERE pipeline_name = 'defensibility_v1';
  ```

---

## What's next (not in this drop)

Stuff to build later, in roughly the right order:

1. **Real extractor** to replace the stub. Start with claim/equation extraction via a model. Keep gap analysis in a separate pass — different cadence.
2. **Run kinds beyond `full_extraction`**: `rescore_only`, `regap_only`, `reattack_only`. Worker logic to handle these.
3. **Web read layer.** Express/FastAPI service that hits `v_current_snapshot` and renders the snapshot blob.
4. **Embeddings.** Add `pgvector` extension, store SBERT embeddings on `claims.canonical_text` for similarity search and near-duplicate detection.
5. **Cross-snapshot diffing.** "What changed between yesterday's snapshot and today's?" — useful for tracking framework drift.
6. **Backfill orchestration.** A script that takes a new pipeline version and progressively backfills, with rate limiting.

Don't build any of these until the spine is running clean. Spine first, layers on top.
