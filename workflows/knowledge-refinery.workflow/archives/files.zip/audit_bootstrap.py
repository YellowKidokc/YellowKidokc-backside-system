"""
audit_bootstrap.py — One-time setup after schema is deployed.

What it does:
  1. Verifies audit schema exists.
  2. Registers the first pipeline_version (so the watcher can enqueue runs).
  3. (Optional) Registers a vault if --vault-name and --vault-path provided.

Run this once, after deploying audit_schema_v1.sql + audit_schema_v1_1_patch.sql.

Usage:
    python audit_bootstrap.py
    python audit_bootstrap.py --vault-name theophysics_v4 --vault-path "O:\\_Theophysics_v4"
"""

import argparse
import hashlib
import json
import logging
import os
import sys
import psycopg2


def setup_logging():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)],
    )


def get_connection(host, port, user, password, dbname):
    return psycopg2.connect(host=host, port=port, user=user, password=password, dbname=dbname)


def verify_schema(conn) -> bool:
    """Verify the audit schema exists and has the expected tables."""
    expected = {
        "vaults", "documents", "document_versions",
        "claims", "claim_instances",
        "equations", "equation_instances",
        "pipeline_versions", "runs", "snapshots",
        "score_cards", "score_definitions",
        "gap_findings", "gap_types",
        "kill_conditions", "reviewer_attacks",
        "dependencies", "repair_items", "human_reviews",
        "vault_scans",
    }
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT table_name FROM information_schema.tables
            WHERE table_schema = 'audit'
            """
        )
        existing = {r[0] for r in cur.fetchall()}
    missing = expected - existing
    if missing:
        logging.error("missing tables in audit schema: %s", missing)
        return False
    logging.info("audit schema OK (%d tables present)", len(existing))
    return True


def register_pipeline_version(conn, name: str, version: str, config: dict) -> str:
    """Register a pipeline version. Idempotent on (name, config_hash)."""
    config_blob = json.dumps(config, sort_keys=True)
    config_hash = hashlib.sha256(config_blob.encode("utf-8")).hexdigest()

    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT pipeline_version_id FROM audit.pipeline_versions
            WHERE pipeline_name = %s AND config_hash = %s
            """,
            (name, config_hash),
        )
        row = cur.fetchone()
        if row:
            logging.info("pipeline %s/%s already registered: %s", name, version, row[0])
            return row[0]

        cur.execute(
            """
            INSERT INTO audit.pipeline_versions
                (pipeline_name, version_tag, config, config_hash)
            VALUES (%s, %s, %s, %s)
            RETURNING pipeline_version_id
            """,
            (name, version, json.dumps(config), config_hash),
        )
        pv_id = cur.fetchone()[0]
    conn.commit()
    logging.info("registered pipeline %s/%s -> %s", name, version, pv_id)
    return pv_id


def register_vault(conn, name: str, path: str) -> str:
    with conn.cursor() as cur:
        cur.execute("SELECT vault_id FROM audit.vaults WHERE vault_name = %s", (name,))
        row = cur.fetchone()
        if row:
            logging.info("vault %s already registered: %s", name, row[0])
            return row[0]
        cur.execute(
            """
            INSERT INTO audit.vaults (vault_name, vault_root_path)
            VALUES (%s, %s)
            RETURNING vault_id
            """,
            (name, path),
        )
        vid = cur.fetchone()[0]
    conn.commit()
    logging.info("registered vault %s -> %s", name, vid)
    return vid


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--vault-name", help="Optional: register a vault now")
    ap.add_argument("--vault-path", help="Optional: vault path on disk")
    ap.add_argument("--host", default="192.168.1.97")
    ap.add_argument("--port", type=int, default=5432)
    ap.add_argument("--user", default="postgres")
    ap.add_argument("--password", default=os.environ.get("PG_PASSWORD", ""))
    ap.add_argument("--dbname", default="theophysics")
    args = ap.parse_args()

    setup_logging()

    if not args.password:
        logging.error("No PG password. Set --password or PG_PASSWORD env var.")
        sys.exit(2)

    conn = get_connection(args.host, args.port, args.user, args.password, args.dbname)
    try:
        if not verify_schema(conn):
            logging.error("Schema verification failed. Did you run audit_schema_v1.sql + v1_1 patch?")
            sys.exit(1)

        # Register the v1 stub pipeline. This is what the worker uses.
        register_pipeline_version(
            conn,
            name="defensibility_v1",
            version="0.1.0-stub",
            config={
                "extractor": "stub",
                "extractor_version": "0.1.0",
                "modules": ["claims", "equations", "scores", "gaps"],
                "pending_modules": ["evidence_chain", "kill_arch", "domain_boundary",
                                    "reviewer_attacks", "dependencies"],
                "notes": "v1 stub for end-to-end pipeline validation. Replace with real extractor.",
            },
        )

        if args.vault_name and args.vault_path:
            register_vault(conn, args.vault_name, args.vault_path)

        logging.info("bootstrap complete")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
