"""
audit_status.py — Show the current state of the audit database.

This is the heartbeat. Run it any time you want to know:
  - Are the vaults being scanned?
  - How much pending work is there?
  - What snapshots are current?
  - What gaps are critical?
  - What's in the repair backlog?

Read-only. Safe to run anytime, even while watcher and workers are running.

Usage:
    python audit_status.py
    python audit_status.py --json     # machine-readable
    python audit_status.py --doc-id <uuid>   # detailed view of one document
"""

import argparse
import json
import os
import sys
import psycopg2
import psycopg2.extras


def get_connection(host, port, user, password, dbname):
    return psycopg2.connect(host=host, port=port, user=user, password=password, dbname=dbname)


def fetch_all(conn, sql, params=None):
    with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
        cur.execute(sql, params or ())
        return [dict(r) for r in cur.fetchall()]


def fmt_minutes(m):
    if m is None:
        return "never"
    if m < 1:
        return "<1 min ago"
    if m < 60:
        return f"{int(m)} min ago"
    if m < 60 * 24:
        return f"{m/60:.1f} hr ago"
    return f"{m/60/24:.1f} days ago"


def status_report(conn) -> dict:
    report = {}

    # Vault health
    report["vaults"] = fetch_all(conn, "SELECT * FROM audit.v_vault_health")

    # Pending work by pipeline
    report["pending_work"] = fetch_all(conn, "SELECT * FROM audit.v_pending_work")

    # Document counts per vault
    report["doc_counts"] = fetch_all(
        conn,
        """
        SELECT v.vault_name,
               COUNT(*) FILTER (WHERE d.deleted_at IS NULL) AS live_docs,
               COUNT(*) FILTER (WHERE d.deleted_at IS NOT NULL) AS deleted_docs
        FROM audit.vaults v
        LEFT JOIN audit.documents d ON d.vault_id = v.vault_id
        GROUP BY v.vault_name
        ORDER BY v.vault_name
        """,
    )

    # Snapshot counts (last 24h, last 7d, all time)
    report["snapshot_volume"] = fetch_all(
        conn,
        """
        SELECT
            COUNT(*) FILTER (WHERE created_at > now() - interval '1 day')   AS last_24h,
            COUNT(*) FILTER (WHERE created_at > now() - interval '7 days')  AS last_7d,
            COUNT(*)                                                        AS all_time
        FROM audit.snapshots
        """,
    )

    # Critical findings
    report["critical_findings"] = fetch_all(
        conn,
        """
        SELECT vault_name, COUNT(*) AS findings
        FROM audit.v_critical_findings
        GROUP BY vault_name
        ORDER BY findings DESC
        """,
    )

    # Repair backlog summary
    report["repair_backlog"] = fetch_all(
        conn,
        """
        SELECT priority, COUNT(*) AS items, AVG(days_open)::numeric(10,1) AS avg_days_open
        FROM audit.v_repair_backlog
        GROUP BY priority
        ORDER BY
          CASE priority
            WHEN 'critical' THEN 1 WHEN 'high' THEN 2
            WHEN 'medium' THEN 3 WHEN 'low' THEN 4
          END
        """,
    )

    # Claim reach (most-cross-vault claims)
    report["top_claims_by_reach"] = fetch_all(
        conn,
        """
        SELECT canonical_text, instance_count, vault_count
        FROM audit.v_claim_reach
        ORDER BY vault_count DESC, instance_count DESC
        LIMIT 10
        """,
    )

    return report


def doc_detail(conn, doc_id: str) -> dict:
    detail = {}
    detail["document"] = fetch_all(
        conn,
        """
        SELECT d.*, v.vault_name
        FROM audit.documents d
        JOIN audit.vaults v ON v.vault_id = d.vault_id
        WHERE d.doc_id = %s
        """,
        (doc_id,),
    )
    detail["versions"] = fetch_all(
        conn,
        """
        SELECT doc_version_id, content_hash, word_count, captured_at, superseded_at
        FROM audit.document_versions
        WHERE doc_id = %s
        ORDER BY captured_at DESC
        """,
        (doc_id,),
    )
    detail["snapshots"] = fetch_all(
        conn,
        """
        SELECT s.snapshot_id, s.created_at, r.run_kind, r.status, pv.pipeline_name, pv.version_tag
        FROM audit.snapshots s
        JOIN audit.runs r              ON r.run_id = s.run_id
        JOIN audit.document_versions dv ON dv.doc_version_id = s.doc_version_id
        JOIN audit.pipeline_versions pv ON pv.pipeline_version_id = r.pipeline_version_id
        WHERE dv.doc_id = %s
        ORDER BY s.created_at DESC
        LIMIT 20
        """,
        (doc_id,),
    )
    return detail


def print_text_report(report: dict):
    print("=" * 70)
    print("AUDIT DATABASE STATUS")
    print("=" * 70)

    print("\n[VAULTS]")
    if not report["vaults"]:
        print("  (no vaults registered)")
    for v in report["vaults"]:
        print(f"  {v['vault_name']}: last scan {fmt_minutes(v.get('minutes_since_scan'))}, "
              f"status={v.get('last_scan_status')}, "
              f"seen={v.get('files_seen')} new={v.get('files_new')} "
              f"changed={v.get('files_changed')} deleted={v.get('files_deleted')}")

    print("\n[DOC COUNTS]")
    for d in report["doc_counts"]:
        print(f"  {d['vault_name']}: {d['live_docs']} live, {d['deleted_docs']} deleted")

    print("\n[PENDING WORK]")
    if not report["pending_work"]:
        print("  (no pending or running runs)")
    for w in report["pending_work"]:
        print(f"  {w['pipeline_name']}/{w['version_tag']} ({w['run_kind']}): "
              f"pending={w['pending']} running={w['running']} failed={w['failed']}")

    print("\n[SNAPSHOT VOLUME]")
    if report["snapshot_volume"]:
        sv = report["snapshot_volume"][0]
        print(f"  last 24h: {sv['last_24h']}    last 7d: {sv['last_7d']}    all time: {sv['all_time']}")

    print("\n[CRITICAL FINDINGS by vault]")
    if not report["critical_findings"]:
        print("  (none)")
    for f in report["critical_findings"]:
        print(f"  {f['vault_name']}: {f['findings']} major/critical findings")

    print("\n[REPAIR BACKLOG]")
    if not report["repair_backlog"]:
        print("  (empty)")
    for r in report["repair_backlog"]:
        print(f"  {r['priority']}: {r['items']} items, avg {r['avg_days_open']} days open")

    print("\n[TOP CLAIMS BY CROSS-VAULT REACH]")
    if not report["top_claims_by_reach"]:
        print("  (no claims yet)")
    for c in report["top_claims_by_reach"]:
        text = c['canonical_text'][:70] + ("..." if len(c['canonical_text']) > 70 else "")
        print(f"  [{c['vault_count']}v / {c['instance_count']}x] {text}")

    print()


def print_doc_detail(detail: dict):
    if not detail["document"]:
        print("Document not found.")
        return
    d = detail["document"][0]
    print(f"\n{'=' * 70}\nDOCUMENT: {d.get('title') or d['relative_path']}")
    print(f"vault: {d['vault_name']}")
    print(f"path:  {d['relative_path']}")
    print(f"first seen: {d['first_seen_at']}    last seen: {d['last_seen_at']}")
    print(f"deleted: {d['deleted_at'] or 'no'}")

    print(f"\n[VERSIONS] ({len(detail['versions'])} total)")
    for v in detail["versions"][:10]:
        live = "" if v["superseded_at"] else "  <-- current"
        print(f"  {v['captured_at']}  hash={v['content_hash'][:12]}  words={v['word_count']}{live}")

    print(f"\n[SNAPSHOTS] ({len(detail['snapshots'])} most recent)")
    for s in detail["snapshots"]:
        print(f"  {s['created_at']}  {s['pipeline_name']}/{s['version_tag']}  "
              f"{s['run_kind']}/{s['status']}  id={str(s['snapshot_id'])[:8]}")
    print()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--doc-id", help="Show detail for a specific document")
    ap.add_argument("--json", action="store_true", help="Output JSON")
    ap.add_argument("--host", default="192.168.1.97")
    ap.add_argument("--port", type=int, default=5432)
    ap.add_argument("--user", default="postgres")
    ap.add_argument("--password", default=os.environ.get("PG_PASSWORD", ""))
    ap.add_argument("--dbname", default="theophysics")
    args = ap.parse_args()

    if not args.password:
        print("No PG password. Set --password or PG_PASSWORD env var.", file=sys.stderr)
        sys.exit(2)

    conn = get_connection(args.host, args.port, args.user, args.password, args.dbname)
    try:
        if args.doc_id:
            detail = doc_detail(conn, args.doc_id)
            if args.json:
                print(json.dumps(detail, default=str, indent=2))
            else:
                print_doc_detail(detail)
        else:
            report = status_report(conn)
            if args.json:
                print(json.dumps(report, default=str, indent=2))
            else:
                print_text_report(report)
    finally:
        conn.close()


if __name__ == "__main__":
    main()
