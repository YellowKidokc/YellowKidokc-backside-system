"""
audit_worker.py — The extraction worker.

Picks up pending runs from audit.runs, processes them, writes snapshots.
Designed for safe concurrency: multiple workers can run simultaneously.

Architecture:
  - Worker loop: claim a run with FOR UPDATE SKIP LOCKED (no race conditions).
  - Extractor: pluggable. v1 ships with a stub extractor for end-to-end testing.
  - Output: writes claim_instances, equation_instances, score_cards, gap_findings,
            and one immutable snapshot row.
  - Failure: any exception marks the run failed with the error message.

To plug in a real extractor:
  - Implement the Extractor interface.
  - Pass it via --extractor (registers in EXTRACTORS dict below).

Usage:
    python audit_worker.py --once             # process one pending run and exit
    python audit_worker.py --loop             # process forever, polling every 5s
    python audit_worker.py --reap             # mark stale 'running' runs as failed
"""

import argparse
import hashlib
import json
import logging
import os
import sys
import time
import traceback
from datetime import datetime, timezone
from typing import Any
import psycopg2
import psycopg2.extras

WORKER_VERSION = "audit_worker@0.1.0"
STALE_RUN_MINUTES = 30  # runs stuck in 'running' longer than this get reaped


# ============================================================
# EXTRACTOR INTERFACE
# Implement this to plug in real model-based extraction.
# ============================================================
class Extractor:
    """Interface for extraction backends."""
    name: str = "base"
    version: str = "0.0.0"

    def extract(self, raw_markdown: str, doc_version_id: str) -> dict:
        """
        Returns a dict with these keys (all optional, all lists):
            {
              "claims":     [{"raw_text": str, "section_path": str, "domain": str, "claim_type": str, "char_start": int, "char_end": int}, ...],
              "equations":  [{"raw_latex": str, "section_path": str, "variables": dict, "parent_law": int}, ...],
              "scores":     [{"score_name": str, "score_value": float, "score_label": str, "confidence": float, "rationale": str}, ...],
              "gaps":       [{"gap_code": str, "severity": str, "location": dict, "description": str, "evidence": str}, ...],
              "snapshot_sections": {"section_name": "complete"|"pending"|"failed"|"skipped", ...},
              "snapshot_blob":     {... arbitrary structured render data ...},
            }
        """
        raise NotImplementedError


class StubExtractor(Extractor):
    """
    Placeholder extractor. Does enough to prove the pipeline works end-to-end.
    - Pulls H2/H3 headings as 'section markers'.
    - Pulls $$...$$ blocks as equations.
    - Pulls lines starting with '> claim:' as claims (a temporary convention).
    - Generates a deterministic 'completeness' score from word count.
    - Flags missing equation if doc has none.
    Replace this with a real extractor when ready.
    """
    name = "stub"
    version = "0.1.0"

    def extract(self, raw_markdown: str, doc_version_id: str) -> dict:
        import re

        claims = []
        equations = []
        gaps = []

        # naive section tracking
        current_section = ""
        for line in raw_markdown.splitlines():
            m = re.match(r"^(#{2,6})\s+(.+)$", line)
            if m:
                current_section = m.group(2).strip()
                continue
            cm = re.match(r"^>\s*claim\s*:\s*(.+)$", line, re.IGNORECASE)
            if cm:
                claims.append({
                    "raw_text": cm.group(1).strip(),
                    "section_path": current_section,
                    "domain": "unknown",
                    "claim_type": "assertion",
                    "char_start": None,
                    "char_end": None,
                })

        # extract $$...$$ equations (very rough)
        for em in re.finditer(r"\$\$(.+?)\$\$", raw_markdown, re.DOTALL):
            equations.append({
                "raw_latex": em.group(1).strip(),
                "section_path": "",
                "variables": None,
                "parent_law": None,
            })

        # cheap "score": completeness based on having both claims and equations
        wc = len(raw_markdown.split())
        completeness = min(1.0, wc / 1000.0)
        scores = [
            {
                "score_name": "academic_readiness",
                "score_value": 0.3 if not claims else 0.5,
                "score_label": None,
                "confidence": 0.2,
                "rationale": f"stub extractor; {len(claims)} claims, {len(equations)} equations, {wc} words",
            },
        ]

        # cheap gap: if no claims found, that's evidence-shaped
        if not claims:
            gaps.append({
                "gap_code": "EVIDENCE",
                "severity": "minor",
                "location": {"section": "(whole document)"},
                "description": "Stub extractor found no '> claim:' markers in document.",
                "evidence": "",
            })
        if not equations:
            gaps.append({
                "gap_code": "EQUATION",
                "severity": "info",
                "location": {"section": "(whole document)"},
                "description": "No equations detected.",
                "evidence": "",
            })

        snapshot_blob = {
            "doc_version_id": doc_version_id,
            "extractor": f"{self.name}@{self.version}",
            "extracted_at": datetime.now(timezone.utc).isoformat(),
            "summary": {
                "claim_count": len(claims),
                "equation_count": len(equations),
                "word_count": wc,
                "completeness_estimate": completeness,
            },
            "claims": claims,
            "equations": equations,
            "scores": scores,
            "gaps": gaps,
        }

        section_status = {
            "claims":           "complete" if claims else "complete",  # "complete" = ran successfully even if empty
            "equations":        "complete",
            "evidence_chain":   "pending",
            "kill_arch":        "pending",
            "domain_boundary":  "pending",
            "reviewer_attacks": "pending",
            "scores":           "complete",
            "gaps":             "complete",
            "dependencies":     "pending",
        }

        return {
            "claims": claims,
            "equations": equations,
            "scores": scores,
            "gaps": gaps,
            "snapshot_sections": section_status,
            "snapshot_blob": snapshot_blob,
        }


EXTRACTORS = {
    "stub": StubExtractor,
}


# ============================================================
# CANONICALIZATION
# Determines if two extracted claims are "the same claim".
# Conservative: hash exact normalized text. Near-duplicates get separate
# claim_id rows, flagged for human review later.
# ============================================================
def canonicalize_claim_text(raw_text: str) -> str:
    """Normalize for hashing. Lowercase, collapse whitespace, strip punctuation edges."""
    import re
    t = raw_text.strip().lower()
    t = re.sub(r"\s+", " ", t)
    t = t.strip(".,;:!?\"'`()[]{}—–-")
    return t


def claim_hash(canonical_text: str) -> str:
    return hashlib.sha256(canonical_text.encode("utf-8")).hexdigest()


def upsert_claim(cur, raw_text: str, domain: str, claim_type: str, canonicalized_by: str) -> str:
    canonical = canonicalize_claim_text(raw_text)
    h = claim_hash(canonical)
    cur.execute("SELECT claim_id FROM audit.claims WHERE canonical_hash = %s", (h,))
    row = cur.fetchone()
    if row:
        return row[0]
    cur.execute(
        """
        INSERT INTO audit.claims (canonical_text, canonical_hash, domain, claim_type, canonicalized_by)
        VALUES (%s, %s, %s, %s, %s)
        RETURNING claim_id
        """,
        (canonical, h, domain, claim_type, canonicalized_by),
    )
    return cur.fetchone()[0]


def upsert_equation(cur, raw_latex: str, variables: dict, parent_law: int, canonicalized_by: str) -> str:
    canonical = " ".join(raw_latex.split())  # naive normalization
    h = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    cur.execute("SELECT equation_id FROM audit.equations WHERE canonical_hash = %s", (h,))
    row = cur.fetchone()
    if row:
        return row[0]
    cur.execute(
        """
        INSERT INTO audit.equations (canonical_form, canonical_hash, variables, parent_law)
        VALUES (%s, %s, %s, %s)
        RETURNING equation_id
        """,
        (canonical, h, psycopg2.extras.Json(variables) if variables else None, parent_law),
    )
    return cur.fetchone()[0]


# ============================================================
# WORKER LOOP
# ============================================================
def claim_a_run(conn) -> dict | None:
    """
    Atomically grab one pending run. Returns its dict or None if nothing pending.
    Uses FOR UPDATE SKIP LOCKED so multiple workers don't fight over the same row.
    """
    with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
        cur.execute(
            """
            SELECT r.run_id, r.pipeline_version_id, r.doc_version_id, r.run_kind,
                   r.source_snapshot_id, dv.raw_markdown, dv.doc_id,
                   pv.pipeline_name, pv.version_tag
            FROM audit.runs r
            JOIN audit.document_versions dv ON dv.doc_version_id = r.doc_version_id
            JOIN audit.pipeline_versions pv ON pv.pipeline_version_id = r.pipeline_version_id
            WHERE r.status = 'pending'
            ORDER BY r.run_id
            FOR UPDATE OF r SKIP LOCKED
            LIMIT 1
            """
        )
        row = cur.fetchone()
        if not row:
            conn.commit()
            return None
        cur.execute(
            "UPDATE audit.runs SET status = 'running', started_at = now() WHERE run_id = %s",
            (row["run_id"],),
        )
    conn.commit()
    return dict(row)


def write_snapshot_and_outputs(conn, run: dict, result: dict, extractor: Extractor):
    """One transaction: insert snapshot, claim_instances, equation_instances, scores, gaps. Mark run complete."""
    snapshot_blob = result["snapshot_blob"]
    snapshot_blob_json = json.dumps(snapshot_blob, sort_keys=True, default=str)
    snapshot_hash = hashlib.sha256(snapshot_blob_json.encode("utf-8")).hexdigest()
    extractor_tag = f"{extractor.name}@{extractor.version}"

    with conn.cursor() as cur:
        # 1. snapshot row
        cur.execute(
            """
            INSERT INTO audit.snapshots
                (run_id, doc_version_id, snapshot_json, snapshot_hash, section_status)
            VALUES (%s, %s, %s, %s, %s)
            RETURNING snapshot_id, created_at
            """,
            (
                run["run_id"],
                run["doc_version_id"],
                psycopg2.extras.Json(snapshot_blob),
                snapshot_hash,
                psycopg2.extras.Json(result["snapshot_sections"]),
            ),
        )
        snapshot_id, snapshot_created_at = cur.fetchone()

        # 2. claim instances
        for c in result.get("claims", []):
            claim_id = upsert_claim(
                cur,
                c["raw_text"],
                c.get("domain", "unknown"),
                c.get("claim_type", "assertion"),
                extractor_tag,
            )
            cur.execute(
                """
                INSERT INTO audit.claim_instances
                    (claim_id, doc_version_id, raw_text, section_path,
                     char_start, char_end, extractor)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    claim_id,
                    run["doc_version_id"],
                    c["raw_text"],
                    c.get("section_path"),
                    c.get("char_start"),
                    c.get("char_end"),
                    extractor_tag,
                ),
            )

        # 3. equation instances
        for e in result.get("equations", []):
            eq_id = upsert_equation(
                cur,
                e["raw_latex"],
                e.get("variables"),
                e.get("parent_law"),
                extractor_tag,
            )
            cur.execute(
                """
                INSERT INTO audit.equation_instances
                    (equation_id, doc_version_id, raw_latex, section_path, extractor)
                VALUES (%s, %s, %s, %s, %s)
                """,
                (
                    eq_id,
                    run["doc_version_id"],
                    e["raw_latex"],
                    e.get("section_path"),
                    extractor_tag,
                ),
            )

        # 4. scores
        for s in result.get("scores", []):
            cur.execute(
                """
                INSERT INTO audit.score_cards
                    (snapshot_id, snapshot_created_at, score_name, score_value,
                     score_label, confidence, rationale, scorer_version)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    snapshot_id,
                    snapshot_created_at,
                    s["score_name"],
                    s.get("score_value"),
                    s.get("score_label"),
                    s.get("confidence"),
                    s.get("rationale"),
                    extractor_tag,
                ),
            )

        # 5. gap findings
        for g in result.get("gaps", []):
            cur.execute(
                """
                INSERT INTO audit.gap_findings
                    (snapshot_id, snapshot_created_at, gap_code, severity,
                     location, description, evidence, finder_version)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    snapshot_id,
                    snapshot_created_at,
                    g["gap_code"],
                    g.get("severity", "info"),
                    psycopg2.extras.Json(g.get("location")) if g.get("location") else None,
                    g["description"],
                    g.get("evidence"),
                    extractor_tag,
                ),
            )

        # 6. mark run complete
        cur.execute(
            "UPDATE audit.runs SET status = 'complete', finished_at = now() WHERE run_id = %s",
            (run["run_id"],),
        )

    conn.commit()
    return snapshot_id


def fail_run(conn, run_id: str, error: str):
    """Mark a run failed with truncated error message."""
    try:
        conn.rollback()
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE audit.runs
                SET status = 'failed', finished_at = now(), error_message = %s
                WHERE run_id = %s
                """,
                (error[:2000], run_id),
            )
        conn.commit()
    except Exception as e:
        logging.error("failed to mark run failed: %s", e)


def reap_stale_runs(conn, stale_minutes: int = STALE_RUN_MINUTES) -> int:
    """Mark runs stuck in 'running' for too long as failed."""
    with conn.cursor() as cur:
        cur.execute(
            """
            UPDATE audit.runs
            SET status = 'failed',
                finished_at = now(),
                error_message = 'reaped: stuck in running for >%s minutes'
            WHERE status = 'running'
              AND started_at < now() - (%s || ' minutes')::interval
            """,
            (stale_minutes, stale_minutes),
        )
        n = cur.rowcount
    conn.commit()
    return n


def process_one(conn, extractor: Extractor) -> bool:
    """Returns True if a run was processed, False if no pending work."""
    run = claim_a_run(conn)
    if not run:
        return False

    logging.info(
        "processing run=%s pipeline=%s/%s doc_version=%s kind=%s",
        run["run_id"], run["pipeline_name"], run["version_tag"],
        run["doc_version_id"], run["run_kind"],
    )

    if run["run_kind"] != "full_extraction":
        # v1 worker only handles full_extraction. Other kinds will be added later.
        fail_run(conn, run["run_id"], f"run_kind={run['run_kind']} not implemented in v1 worker")
        return True

    try:
        result = extractor.extract(run["raw_markdown"], run["doc_version_id"])
        snap_id = write_snapshot_and_outputs(conn, run, result, extractor)
        logging.info("complete run=%s snapshot=%s", run["run_id"], snap_id)
    except Exception as e:
        tb = traceback.format_exc()
        logging.error("run %s failed: %s\n%s", run["run_id"], e, tb)
        fail_run(conn, run["run_id"], f"{e}\n{tb}")
    return True


# ============================================================
# CLI
# ============================================================
def setup_logging(log_path):
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.FileHandler(log_path, encoding="utf-8"), logging.StreamHandler(sys.stdout)],
    )


def get_connection(host, port, user, password, dbname):
    return psycopg2.connect(host=host, port=port, user=user, password=password, dbname=dbname)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--once", action="store_true", help="Process one run and exit")
    ap.add_argument("--loop", action="store_true", help="Process forever, polling")
    ap.add_argument("--reap", action="store_true", help="Reap stale running runs and exit")
    ap.add_argument("--poll-seconds", type=float, default=5.0)
    ap.add_argument("--extractor", default="stub", choices=list(EXTRACTORS.keys()))
    ap.add_argument("--host", default="192.168.1.97")
    ap.add_argument("--port", type=int, default=5432)
    ap.add_argument("--user", default="postgres")
    ap.add_argument("--password", default=os.environ.get("PG_PASSWORD", ""))
    ap.add_argument("--dbname", default="theophysics")
    ap.add_argument("--log", default="audit_worker.log")
    args = ap.parse_args()

    setup_logging(args.log)

    if not args.password:
        logging.error("No PG password. Set --password or PG_PASSWORD env var.")
        sys.exit(2)

    if not (args.once or args.loop or args.reap):
        ap.error("must pass one of --once, --loop, --reap")

    conn = get_connection(args.host, args.port, args.user, args.password, args.dbname)
    extractor = EXTRACTORS[args.extractor]()
    logging.info("worker=%s extractor=%s@%s", WORKER_VERSION, extractor.name, extractor.version)

    try:
        if args.reap:
            n = reap_stale_runs(conn)
            logging.info("reaped %d stale runs", n)
            return

        if args.once:
            did = process_one(conn, extractor)
            if not did:
                logging.info("no pending work")
            return

        if args.loop:
            logging.info("entering loop, poll every %.1fs", args.poll_seconds)
            idle_count = 0
            while True:
                try:
                    did = process_one(conn, extractor)
                    if did:
                        idle_count = 0
                    else:
                        idle_count += 1
                        if idle_count % 12 == 1:  # log idle every minute or so
                            logging.info("idle (no pending work)")
                        time.sleep(args.poll_seconds)
                except KeyboardInterrupt:
                    logging.info("interrupted, exiting")
                    return
                except Exception as e:
                    logging.error("loop error: %s", e)
                    time.sleep(args.poll_seconds * 2)
                    # Reconnect on hard DB errors.
                    try:
                        conn.close()
                    except Exception:
                        pass
                    conn = get_connection(args.host, args.port, args.user, args.password, args.dbname)
    finally:
        try:
            conn.close()
        except Exception:
            pass


if __name__ == "__main__":
    main()
